var class_army_unit =
[
    [ "ArmyUnit", "class_army_unit.html#adbd23057507044c77cc8520b33eac413", null ],
    [ "attackUnit", "class_army_unit.html#a789c99557b980e00f9b07710dce266a0", null ],
    [ "getCountry", "class_army_unit.html#a4a682bb1ce96f7822538ec0a99f0fd5e", null ],
    [ "getCurrentLocationName", "class_army_unit.html#ad34fe1d13685a417e02559bd7028078d", null ],
    [ "getCurrentNode", "class_army_unit.html#a8e77407b9af6be87acbc1c1f466213c3", null ],
    [ "getDamage", "class_army_unit.html#a34d4690c1929dde12142b50e299d3ea1", null ],
    [ "getDamaged", "class_army_unit.html#a98ca966f298a9760f658bced6b6e41d6", null ],
    [ "getRange", "class_army_unit.html#a70e53ff4c2358b9a40a0066c4726d433", null ],
    [ "getTarget", "class_army_unit.html#aff75bd2d37d73ef37f95076ea31fd886", null ],
    [ "getUnitType", "class_army_unit.html#a9c5dab8a95e60ab4bc37830520b4d864", null ],
    [ "moveOptions", "class_army_unit.html#a8186cf64e1c73bcede8dfb2ec6ae3113", null ],
    [ "printTargets", "class_army_unit.html#aa50197fb10b3cde4c3dea6d7cdf9fa48", null ],
    [ "removeDuplicates", "class_army_unit.html#a1395ec1ff3b152cdbeccbb06afd78b06", null ],
    [ "setDamage", "class_army_unit.html#a881fce0823a9fa34a80d19da62ebba0f", null ],
    [ "setNode", "class_army_unit.html#a75fddcd808d93717076e63851aad9edb", null ],
    [ "setRange", "class_army_unit.html#a73c145c70c0ad317b6e98825293370ae", null ],
    [ "supplyUnit", "class_army_unit.html#a663ab76a87832f55eabee257f1d2e1a9", null ]
];