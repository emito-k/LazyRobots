var class_infantry_unit_factory =
[
    [ "createUnit", "class_infantry_unit_factory.html#a3cb6cafaab923b503a83c1ad3f991d2e", null ]
];