var class_military_factory =
[
    [ "createUnit", "class_military_factory.html#abeb2f5ff0d9a2ced9ee76a8a5c60ef82", null ]
];