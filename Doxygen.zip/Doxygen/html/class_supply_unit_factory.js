var class_supply_unit_factory =
[
    [ "createUnit", "class_supply_unit_factory.html#aec6df84cb44108dbbc8bf9bd2ad8bd28", null ]
];