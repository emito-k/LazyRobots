var hierarchy =
[
    [ "ArmyUnit", "class_army_unit.html", [
      [ "AttackHelicopterUnit", "class_attack_helicopter_unit.html", null ],
      [ "InfantryUnit", "class_infantry_unit.html", null ],
      [ "SupplyUnit", "class_supply_unit.html", null ],
      [ "TankUnit", "class_tank_unit.html", null ]
    ] ],
    [ "Country", "class_country.html", null ],
    [ "Flag", "class_flag.html", null ],
    [ "FlagState", "class_flag_state.html", [
      [ "HomeFlagState", "class_home_flag_state.html", null ],
      [ "WhiteFlagState", "class_white_flag_state.html", null ]
    ] ],
    [ "Graph", "class_graph.html", null ],
    [ "MilitaryFactory", "class_military_factory.html", [
      [ "AttackHelicopterUnitFactory", "class_attack_helicopter_unit_factory.html", null ],
      [ "InfantryUnitFactory", "class_infantry_unit_factory.html", null ],
      [ "SupplyUnitFactory", "class_supply_unit_factory.html", null ],
      [ "TankUnitFactory", "class_tank_unit_factory.html", null ]
    ] ],
    [ "Node", "class_node.html", null ],
    [ "Player", "class_player.html", [
      [ "ComputerPlayer", "class_computer_player.html", null ],
      [ "HumanPlayer", "class_human_player.html", null ]
    ] ],
    [ "PlayerCommand", "class_player_command.html", [
      [ "ArmyAttackCommand", "class_army_attack_command.html", null ],
      [ "CreateArmyCommand", "class_create_army_command.html", null ],
      [ "MoveArmyCommand", "class_move_army_command.html", null ],
      [ "SupplyArmyCommand", "class_supply_army_command.html", null ],
      [ "SurrenderCommand", "class_surrender_command.html", null ]
    ] ],
    [ "Terrain", "class_terrain.html", [
      [ "ForestTerrain", "class_forest_terrain.html", null ],
      [ "MountainTerrain", "class_mountain_terrain.html", null ],
      [ "PlainTerrain", "class_plain_terrain.html", null ],
      [ "SwampTerrain", "class_swamp_terrain.html", null ]
    ] ],
    [ "WarEngine", "class_war_engine.html", null ]
];