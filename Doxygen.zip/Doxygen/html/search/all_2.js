var searchData=
[
  ['disconnectnode_0',['disconnectNode',['../class_node.html#aa6386dac6380ced14f3ca597bcfe2764',1,'Node']]],
  ['disconnectnodes_1',['disconnectNodes',['../class_graph.html#aa67b78f991eedbbc36930af0a7609e5e',1,'Graph']]]
];
