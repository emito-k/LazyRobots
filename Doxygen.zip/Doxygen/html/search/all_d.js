var searchData=
[
  ['userconnectnodes_0',['userConnectNodes',['../class_graph.html#af30db468ca4357ece34c964f18bcf783',1,'Graph']]],
  ['userdisconnectnodes_1',['userDisconnectNodes',['../class_graph.html#a8c962958efb94a34e3de609119cdf0fa',1,'Graph']]]
];
