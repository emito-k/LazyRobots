var searchData=
[
  ['moveoptions_0',['moveOptions',['../class_army_unit.html#a8186cf64e1c73bcede8dfb2ec6ae3113',1,'ArmyUnit']]]
];
